public class Main {

}