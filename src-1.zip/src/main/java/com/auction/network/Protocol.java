package com.auction.network;

/**
 * .
 */
public class Protocol {
  // --- COMMANDS (Lệnh từ Client gửi lên) ---
  public static final String CMD_REGISTER = "REGISTER";
  public static final String CMD_LOGIN = "LOGIN";
  public static final String CMD_LIST_AUCTIONS = "LIST_AUCTIONS";
  public static final String CMD_BID = "BID";
  public static final String CMD_CREATE_AUCTION = "CREATE_AUCTION";
  public static final String CMD_END_AUCTION = "END_AUCTION";
  public static final String CMD_GET_HISTORY = "GET_HISTORY";
  public static final String CMD_DEPOSIT = "DEPOSIT";
  public static final String CMD_GET_BALANCE = "GET_BALANCE";
  public static final String CMD_WATCH = "WATCH";
  public static final String CMD_UNWATCH = "UNWATCH";
  public static final String CMD_GET_WATCHLIST = "GET_WATCHLIST";
  public static final String CMD_ADD_AUTO_BID = "ADD_AUTO_BID";
  public static final String CMD_DELETE_AUCTION = "DELETE_AUCTION";

  // --- RESPONSES (Phản hồi từ Server về Client) ---
  public static final String RES_REGISTER_SUCCESS = "REGISTER_SUCCESS";
  public static final String RES_REGISTER_FAILED = "REGISTER_FAILED";
  public static final String RES_LOGIN_SUCCESS = "LOGIN_SUCCESS";
  public static final String RES_LOGIN_FAILED = "LOGIN_FAILED";
  public static final String RES_LIST_SUCCESS = "LIST_AUCTIONS_SUCCESS";
  public static final String RES_BID_SUCCESS = "BID_SUCCESS";
  public static final String RES_HISTORY = "HISTORY_RES";
  public static final String RES_DEPOSIT_SUCCESS = "DEPOSIT_SUCCESS";
  public static final String RES_BALANCE_INFO = "BALANCE_INFO";
  public static final String RES_END_SUCCESS = "END_SUCCESS";
  public static final String RES_SUCCESS = "SUCCESS";
  public static final String RES_WATCHLIST = "RES_WATCHLIST";
  public static final String RES_WATCH_SUCCESS = "WATCH_SUCCESS";
  public static final String RES_UNWATCH_SUCCESS = "UNWATCH_SUCCESS";
  public static final String RES_AUTO_BID_SUCCESS = "AUTO_BID_SUCCESS";
  public static final String RES_DELETE_SUCCESS = "DELETE_SUCCESS";
  public static final String ERROR = "ERROR";

  // --- THÔNG BÁO BIẾN ĐỘNG (PUSH NOTIFICATIONS) ---
  public static final String NOTI_BALANCE_CHANGED = "BALANCE_CHANGED";
  // Thông báo chung cho mọi người: Giá đã tăng
  public static final String NOTI_BID_UPDATE = "BID_UPDATE";
  /**
   * NOTI_OUTBID: Thông báo riêng cho người bị vượt giá
   * Format: OUTBID|auctionId|newBidder|newAmount
   * NEW: Notification đặc biệt chỉ gửi cho người đang giữ giá cao nhất
   * khi họ bị vượt giá bởi người khác.
   * 
   */
  public static final String NOTI_OUTBID = "OUTBID";

  /**
   * NOTI_REFUND: Thông báo khi tiền được hoàn lại vào ví
   * Format: REFUND|auctionId|refundAmount|reason
   * NEW: Notification khi user nhận lại tiền do bị outbid hoặc auction bị hủy.
   * Reasons:
   * - "OUTBID": Bị người khác vượt giá
   * - "AUCTION_CANCELLED": Phiên đấu giá bị hủy
   * - "AUCTION_ENDED": Phiên kết thúc, không phải winner
   */
  public static final String NOTI_REFUND = "REFUND";

  // FIX: Thêm thông báo gia hạn thời gian (Anti-Sniping)
  public static final String NOTI_SNIPING_UPDATE = "SNIPING_UPDATE";

  // tất cả Client đang mở App sẽ thấy món hàng đó tự động hiện ra
  // trên JTable mà không cần phải bấm nút Refresh.
  public static final String NOTI_NEW_AUCTION = "NEW_AUCTION";

  // Delimiter (Ký tự phân tách)
  public static final String SEPARATOR = "|";

  // --- HELPER METHODS ---

  /**
   * Parse notification header từ message string.
   * 
   * @param message Full notification message
   * @return Notification type (header)
   */
  public static String getNotificationHeader(String message) {
    if (message == null || message.isEmpty()) {
      return null;
    }
    String[] parts = message.split("\\" + SEPARATOR);
    return parts.length > 0 ? parts[0] : null;
  }

  /**
   * Kiểm tra xem message có phải là notification type không. 
   * @param   message cần kiểm tra. 
   * @param notificationType Protocol constant (e.g., NOTI_BID_UPDATE)
   * @return true nếu message thuộc type này
   */
  public static boolean isNotificationType(String message, String notificationType) {
    String header = getNotificationHeader(message);
    return header != null && header.equals(notificationType);
  }

}