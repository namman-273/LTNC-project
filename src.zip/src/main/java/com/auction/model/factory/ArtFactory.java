package com.auction.model.factory;

import com.auction.model.entities.item.Art;
import com.auction.model.entities.item.Item;

/**
 * Art factory khởi tạo chi tiết Art.
 */
public class ArtFactory extends ItemFactory {

  @Override
  public Item create(String id, String name, double price) {
    return new Art(id, name, price); // Gọi đến class Art.java 
  }
}
