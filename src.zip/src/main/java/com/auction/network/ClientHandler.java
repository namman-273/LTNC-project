package com.auction.network;

import com.auction.model.User;
import com.auction.model.Auction;
import com.auction.service.AuctionService;
import com.auction.model.Observer;
import com.auction.service.UserManager; // Import UserManager Singleton
import com.google.gson.Gson;
import com.auction.exception.AuthenticationException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ClientHandler implements Runnable, Observer {

    private static final int REQ_REGISTER = 4; // REGISTER|user|pass|role
    private static final int REQ_LOGIN = 3; // LOGIN|user|pass
    private static final int REQ_BID = 3; // BID|auctionId|amount
    private static final int REQ_CREATE = 5; // CREATE_AUCTION|type|name|price|min
    private static final int REQ_END = 2; // END_AUCTION|auctionId
    private static final int REQ_HISTORY = 2; // GET_HISTORY|auctionId

    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private final Gson gson = new Gson();
    private User currentUser;

    public ClientHandler(final Socket socket) {
        this.socket = socket;
    }

    /**
     * Hàm Helper kiểm tra độ dài Payload để chống ArrayIndexOutOfBoundsException.
     * 
     */
    private boolean validatePayload(String[] parts, int expectedLength) {
        if (parts == null || parts.length < expectedLength) {
            sendMessage("ERROR|Thiếu tham số yêu cầu. Cần ít nhất " + expectedLength + " phần.");
            return false;
        }
        return true;
    }

    @Override
    public final void run() {
        AuctionService auctionService = AuctionService.getInstance();
        try {
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            String request;
            while ((request = in.readLine()) != null) {
                String[] parts = request.trim().split("\\|");
                if (parts.length == 0)
                    continue;
                String cmd = parts[0];

                switch (cmd) {
                    case Protocol.CMD_REGISTER:
                        if (validatePayload(parts, REQ_REGISTER))
                            handleRegister(parts);
                        break;
                    case Protocol.CMD_LOGIN:
                        if (validatePayload(parts, REQ_LOGIN))
                            handleLogin(parts, auctionService);
                        break;
                    case Protocol.CMD_LIST_AUCTIONS:
                        handleListAuctions(auctionService);
                        break;
                    case Protocol.CMD_BID:
                        if (validatePayload(parts, REQ_BID))
                            handleBid(parts, auctionService);
                        break;
                    case Protocol.CMD_CREATE_AUCTION:
                        if (validatePayload(parts, REQ_CREATE))
                            handleCreateAuction(parts, auctionService);
                        break;
                    case Protocol.CMD_END_AUCTION:
                        if (validatePayload(parts, REQ_END))
                            handleEndAuction(parts, auctionService);
                        break;
                    case Protocol.CMD_GET_HISTORY:
                        if (validatePayload(parts, REQ_HISTORY))
                            handleGetHistory(parts, auctionService);
                        break;
                    default:
                        sendMessage(Protocol.ERROR + Protocol.SEPARATOR + "Lệnh không hợp lệ");
                }
            }
        } catch (IOException e) {
            System.out.println("Một client đã ngắt kết nối.");
        } finally {
            cleanUp();
        }
    }

    private void handleRegister(final String[] parts) {
        // REGISTER|username|password|role
        boolean success = UserManager.getInstance().register(parts[1], parts[2], parts[3]);
        if (success) {
            sendMessage(Protocol.RES_REGISTER_SUCCESS + Protocol.SEPARATOR + "Đăng ký thành công.");
        } else {
            sendMessage(Protocol.RES_REGISTER_FAILED + Protocol.SEPARATOR + "Tên người dùng đã tồn tại.");
        }
    }

    private void handleLogin(final String[] parts, AuctionService auctionService) {
        // LOGIN|username|password
        try {
            User user = UserManager.getInstance().login(parts[1], parts[2]);
            if (user != null) {
                this.currentUser = user;
                for (Auction auction : auctionService.getAllAuctions()) {
                    auction.addObserver(this);
                }
                sendMessage(Protocol.RES_LOGIN_SUCCESS + Protocol.SEPARATOR + user.getRole() + Protocol.SEPARATOR
                        + "Chào " + user.getUsername());
            }
        } catch (AuthenticationException e) {
            sendMessage(Protocol.RES_LOGIN_FAILED + Protocol.SEPARATOR + e.getMessage());
        }
    }

    private void handleListAuctions(AuctionService auctionService) {
        // Trả về danh sách thô (Trong thực tế nên dùng JSON hoặc toString chuẩn)
        sendMessage(Protocol.RES_LIST_SUCCESS + Protocol.SEPARATOR + auctionService.getAllAuctions().toString());

    }

    private void handleCreateAuction(final String[] parts, AuctionService auctionService) {
        // CREATE_AUCTION|type|name|startingPrice|durationMinutes
        if (currentUser == null || !"ADMIN".equals(currentUser.getRole())) {
            sendMessage(Protocol.ERROR + Protocol.SEPARATOR + "Quyền hạn không đủ.");
            return;
        }
        try {
            String type = parts[1];
            String name = parts[2];
            double price = Double.parseDouble(parts[3]);
            long duration = Long.parseLong(parts[4]);

            auctionService.createNewAuction(type, name, price, duration);
            sendMessage(Protocol.RES_SUCCESS + Protocol.SEPARATOR + "Sản phẩm " + name + " đã được đăng sàn.");
        } catch (Exception e) {
            sendMessage(Protocol.ERROR + Protocol.SEPARATOR + "Dữ liệu tạo sản phẩm không hợp lệ.");
        }
    }

    private void handleEndAuction(final String[] parts, AuctionService auctionService) {
        // Kiểm tra quyền: Chỉ Admin mới được đóng phiên thủ công
        if (currentUser == null || !"ADMIN".equals(currentUser.getRole())) {
            sendMessage(Protocol.ERROR + Protocol.SEPARATOR + "Chỉ Admin mới có quyền đóng phiên.");
            return;
        }
        auctionService.endAuction(parts[1]);
        sendMessage(Protocol.RES_END_SUCCESS + Protocol.SEPARATOR + "Đã đóng phiên " + parts[1]);
    }

    private void handleBid(final String[] parts, AuctionService auctionService) {
        if (this.currentUser == null) {
            sendMessage(Protocol.ERROR + Protocol.SEPARATOR + "Bạn phải đăng nhập trước khi đấu giá!");
            return;
        }

        try {
            String auctionId = parts[1];
            double amount = Double.parseDouble(parts[2]);
            if (amount <= 0) {
                sendMessage(Protocol.ERROR + Protocol.SEPARATOR + "Giá bid phải lớn hơn 0");
                return;
            }
            if (Double.isNaN(amount) || Double.isInfinite(amount)) {
                sendMessage(Protocol.ERROR + Protocol.SEPARATOR +"Giá tiền không hợp lệ (NaN/Infinite)");
                return;
            }

            Auction auction = auctionService.getAuctionById(auctionId);
            if (auction == null) {
                sendMessage(Protocol.ERROR + Protocol.SEPARATOR + "Không tìm thấy phiên đấu giá này");
                return;
            }

            auction.processNewBid(currentUser, amount);
            sendMessage(Protocol.RES_BID_SUCCESS + Protocol.SEPARATOR + auctionId + Protocol.SEPARATOR + amount);
        } catch (

        NumberFormatException e) {
            sendMessage(Protocol.ERROR + Protocol.SEPARATOR + "Giá tiền phải là con số hợp lệ");
        } catch (Exception e) {
            sendMessage(Protocol.ERROR + Protocol.SEPARATOR + e.getMessage());
        }
    }

    /**
     * Xử lý yêu cầu lấy lịch sử giá của một phiên đấu giá.
     * Trả về danh sách BidTransaction dưới dạng JSON để FE vẽ biểu đồ.
     */
    private void handleGetHistory(String[] parts, AuctionService auctionService) {

        String auctionId = parts[1];
        Auction auction = auctionService.getAuctionById(auctionId);

        if (auction != null) {
            try {
                String jsonHistory = gson.toJson(auction.getBidHistory());
                sendMessage(Protocol.RES_HISTORY + Protocol.SEPARATOR + auctionId + Protocol.SEPARATOR + jsonHistory);
            } catch (Exception e) {
                sendMessage(Protocol.ERROR + Protocol.SEPARATOR + "Lỗi xử lý dữ liệu lịch sử: " + e.getMessage());
            }
        } else {
            sendMessage(Protocol.ERROR + Protocol.SEPARATOR + "Không tìm thấy phiên đấu giá với ID: " + auctionId);
        }

    }

    public final void sendMessage(final String msg) {
        if (out != null) {
            out.println(msg);
        }
    }

    public final void update(final String msg) {
        this.sendMessage(msg);
    }

    private void cleanUp() {
        try {
            AuctionService.getInstance().removeObserverFromAll(this);

            if (in != null)
                in.close();
            if (out != null)
                out.close();
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
        } catch (IOException e) {
            System.err.println("Lỗi khi đóng tài nguyên Client: " + e.getMessage());
        }
    }
}
// To-do:chỉnh sang Logger